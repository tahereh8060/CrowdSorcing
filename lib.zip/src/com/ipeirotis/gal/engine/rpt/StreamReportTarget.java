package com.ipeirotis.gal.engine.rpt;

import java.io.PrintStream;

public class StreamReportTarget extends ReportTarget {
	public StreamReportTarget(PrintStream printStream) {
		super(printStream);
	}

}
