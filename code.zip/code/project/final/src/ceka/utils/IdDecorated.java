/**
 * 
 */
package ceka.utils;

/**
 * decorate the class has Ids as the identifiers as their objects
 *
 */
public interface IdDecorated {
	public String getId();
}
